import { MongoClient, Db } from "mongodb";
import { logger } from "@/lib/utils/logger";
import { ensureEnvLoaded } from "@/lib/utils/env";

/**
 * Global MongoDB Connection Singleton
 *
 * Establishes a persistent connection pool upon first request and reuses
 * the shared client across all Next.js API route invocations, avoiding
 * reconnect overhead, unhandled rejections at build time, and connection exhaustion.
 */

declare global {
  // eslint-disable-next-line no-var
  var _mongoClientPromise: Promise<MongoClient> | undefined;
}

export function getMongoUri(): string {
  ensureEnvLoaded();
  return (
    process.env.MONGO_DB ||
    process.env.MONGODB_URI ||
    process.env.DATABASE_URL ||
    ""
  );
}

let clientPromise: Promise<MongoClient> | null = null;

export async function getMongoClient(): Promise<MongoClient> {
  const uri = getMongoUri();
  if (!uri) {
    throw new Error("MONGO_DB environment variable is not configured.");
  }

  // Preserve connection pool across HMR in development
  if (process.env.NODE_ENV === "development" && globalThis._mongoClientPromise) {
    return globalThis._mongoClientPromise;
  }

  if (!clientPromise) {
    const client = new MongoClient(uri, {
      maxPoolSize: 20,
      minPoolSize: 1,
      serverSelectionTimeoutMS: 8000,
    });

    clientPromise = client
      .connect()
      .then((c) => {
        logger.info("MongoDB connection successfully established");
        return c;
      })
      .catch((err) => {
        clientPromise = null; // reset so next request can retry
        logger.error("Failed to connect to MongoDB", { error: err.message });
        throw err;
      });

    if (process.env.NODE_ENV === "development") {
      globalThis._mongoClientPromise = clientPromise;
    }
  }

  return clientPromise;
}

export async function getDb(dbName?: string): Promise<Db> {
  const client = await getMongoClient();
  return client.db(dbName);
}
